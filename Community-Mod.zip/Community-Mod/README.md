# Community-Mod
Mindustry v7 mod developed by everyone that comes across it!

---------------------------------------About---------------------------------------

If you managed to find your way here, you probably like mods. I do, and I also like messing around with them and making the most random stuff the most OP stuff.

Why does this exist? I just had an idea: "What if there was a mod that was developed by the community as a whole instead of 1-3 basement-dwelling dorito dust bunnies?" and I could not pass the idea as just a random "What If" and decided to make this.

Everyone is free to contribute to this mod, however, sadly, the mod can't be OP :c (Maybe I (or you) will make an OP version/option sometime in the future?)
Also i'm not at all experienced with Github to the point where I hear "pull request" and go into a 5-60 second brain ditch of guessing what it means (now I do!) nor know the bare basics of formatting a README.md, so please have patience with me (or roast me to bits idc) anyways it's 9:00 PM so if I want to have a semi-healthy sleep schedule I have to be efficient so uhh rules ig...

---------------------------------------Rules---------------------------------------

Rules:
  1. Please test your stuff before adding, don't wanna oh no the game (also make sure your stuff is compatible with v135)
  
  2. Balance your content. Don't make a "testing" block that gives infinite energy and mass-produces thorium, just... Balance pls.
  
  3. Prioritize compatibility. People want to play with other mods, John. (imagine if sk7725, BlueWolf, Xelo, AureusStratus, Yuria, Slava0135 and Sharlottes contributed to this by dumping all their content here lol) (imagine lol) (haha) (yep, just imagine)
  
  4. (anywhere you can discuss the mod) Don't be holier than thou. Cussing is allowed, *respectfully* roasting each other is allowed. 
   
   4.1. Don't say racist derrogatory slurs or slurs that were considered offensive *before* 2018 (Using "gay" as an insult is allowed as long as it's not straight up homophobia), that stuff is wack.
  
  5. Don't break the TOSs of Github, Mindustry (idk if it has any lol) or Discord (I'm planning on making a server for this mod, or if someone else wants to make a server for this mod)
  
  6. Use common sense. Don't be a dagger.

---------------------------------------Issues and legal stuff---------------------------------------

If you have a problem with something here, discord username is Skrrby#2973.
I am not responsible for Chad the Reddit Mod sharing Joe Biden's Password in here nor any other illegal stuff, i'm just an idiot with some free time.

---------------------------------------Help---------------------------------------

Not a lot going on right now, but if you could contribute a FAQ or something, go ahead.
If you need help with something specific, Google it. If it's about the mod, discord username is 4 lines above this one.

---------------------------------------Credits---------------------------------------

Add yourself here and your contribution to this possible catastrophe in this format:
[Username] - [Added X to Y/Changed X in Y to Z/Moved X in Y to Z/Translated X to Language/ Ect...] [(Day/Month/Year (yeah screw u m/d/y))]

 
 Anuke/Anuken - Created Mindustry in the first place.

 Skrrby - Created this.

 BandaidCheerios - Is also Skrrby.

---------------------------------------Extras---------------------------------------

Idk just add whatever you deem useful here, guides and pictures of the mod ig... or just vent about your issues in life... from here on, it's organized anarchy.

butt :D